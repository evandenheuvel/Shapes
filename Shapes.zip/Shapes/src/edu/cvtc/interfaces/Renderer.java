/**
 * 
 */
package edu.cvtc.interfaces;

/**
 * @author ericvandenheuvel
 *
 */
public interface Renderer {

	public int render();
	
}
