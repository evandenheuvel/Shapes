/**
 * 
 */
package edu.cvtc.interfaces;

/**
 * @author ericvandenheuvel
 *
 */
public interface Dialog {

	public int show(String message, String title);
	
}
