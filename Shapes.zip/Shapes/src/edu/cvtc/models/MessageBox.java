/**
 * 
 */
package edu.cvtc.models;

import javax.swing.JOptionPane;

import edu.cvtc.interfaces.Dialog;

/**
 * @author ericvandenheuvel
 *
 */
public class MessageBox implements Dialog {

	public MessageBox() {
		
	}

	@Override
	public int show(String message, String title) {
		
		JOptionPane.showMessageDialog(null, message, title, 0);
		
		return JOptionPane.OK_OPTION;
	}
	
}
