/**
 * 
 */
package edu.cvtc.models;

import edu.cvtc.interfaces.Dialog;
import edu.cvtc.interfaces.Renderer;

/**
 * @author ericvandenheuvel
 * @version 1.0.0
 * 2/3/19
 */
public class Cylinder extends Shape implements Renderer{

	/**
	 * Section: Fields
	 */
	
	float radius; // initialize float value describing radius
	float height; // initialize float value describing height
	
	/**
	 * Section: Constructors
	 */
	public Cylinder(Dialog messageBox) {
		super(messageBox);
		
		this.radius = 0;
		this.height= 0;

	}

	// constructor with parameters for Cylinder object
	public Cylinder(Dialog messageBox, float radius, float height) {
		super(messageBox);
		
		if (radius > 0 && height > 0) {
			
			this.radius = radius; // assign height of Cylinder to passed in value for radius
			this.height = height; // assign height of Cylinder to passed in value for height
		
		} else {
			
			throw new IllegalArgumentException("Can only accept non-zero, non-negative float values");
			
		}
		
	}

	/**
	 * Section: Methods
	 */

	/* (non-Javadoc)
	 * @see edu.cvtc.models.Shape#surfaceArea()
	 */
	@Override
	public float surfaceArea() {
		
		if (this.radius > 0 && this.height > 0) {
			// return the value of the formula for surface area of a cylinder: 2*pi*r*(r+h)
			return (float) (2.0 * Math.PI * this.radius * (this.radius + this.height));
		
		} else {
			
			throw new IllegalArgumentException("Can only accept non-zero, non-negative float values");
			
		}
		
	}

	/* (non-Javadoc)
	 * @see edu.cvtc.models.Shape#volume()
	 */
	@Override
	public float volume() {
		
		if (this.radius > 0 && this.height > 0) {
			// return the value of the formula for volume of a cylinder: pi*r^2*h
			return (float) (Math.PI * Math.pow(this.radius, 2) * this.height);
			
		} else {
			
			throw new IllegalArgumentException("Can only accept non-zero, non-negative float values");
			
		}
	}

	public int render() {
		
		// pop up a message box with all the dimensions and calculations for the cylinder
		return this.getMessageBox().show(this.toString(), "Cylinder");

	}
	
	/**
	 * Section: Getters
	 */

	/**
	 * @return the radius
	 */
	public float getRadius() {
		return radius;
	}

	/**
	 * @return the height
	 */
	public float getHeight() {
		return height;
	}
	
	/**
	 * Section: Setters
	 */

	/**
	 * @param radius the radius to set
	 */
	public void setRadius(float radius) {
		this.radius = radius;
	}

	/**
	 * @param height the height to set
	 */
	public void setHeight(float height) {
		this.height = height;
	}
	
	/**
	 * Section: ToString
	 * 
	 * set the string value for the class
	 */

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Cylinder [radius=" + this.radius + ", height=" + this.height + ", surfaceArea()=" + this.surfaceArea() + ", volume()="
				+ this.volume() + "]";
	}

}
