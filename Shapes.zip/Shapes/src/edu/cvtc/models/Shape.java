/**
 * 
 */
package edu.cvtc.models;

import edu.cvtc.interfaces.Dialog;

/**
 * @author ericvandenheuvel
 *
 */
public abstract class Shape {
	
	private Dialog messageBox;
	
	protected Dialog getMessageBox() {
		return this.messageBox;
	}
	
	private void setMessageBox(Dialog messageBox) {
		this.messageBox = messageBox;
	}
	
	public Shape(Dialog messageBox) {
		this.messageBox = messageBox;
	}
	
	// abstract method to find the surface area of the shape
	abstract float surfaceArea();
	
	// abstract method to find the volume of the shape
	abstract float volume();

}
