/**
 * 
 */
package edu.cvtc.models;

import edu.cvtc.interfaces.Dialog;

/**
 * @author ericvandenheuvel
 *
 */
public class MessageBoxSub implements Dialog {

	/* (non-Javadoc)
	 * @see edu.cvtc.interfaces.Dialog#show(java.lang.String, java.lang.String)
	 */
	@Override
	public int show(String message, String title) {
		return 0x00;
	}

}
